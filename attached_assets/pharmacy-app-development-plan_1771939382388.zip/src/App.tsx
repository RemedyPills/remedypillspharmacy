import { useState, useEffect } from "react";
import { cn } from "@/utils/cn";

// Types
interface Prescription {
  id: string;
  name: string;
  strength: string;
  directions: string;
  rxNumber: string;
  status: "active" | "processing" | "ready" | "completed";
  lastFillDate: string;
  refillable: boolean;
  refillCount: number;
}

interface Reminder {
  id: string;
  medicationName: string;
  time: string;
  taken: boolean;
  snoozed: boolean;
}

interface Appointment {
  id: string;
  service: string;
  date: string;
  time: string;
  status: "upcoming" | "completed" | "cancelled";
  notes?: string;
}

interface Message {
  id: string;
  sender: "user" | "pharmacist";
  text: string;
  timestamp: string;
  category?: string;
}

interface Location {
  id: string;
  name: string;
  address: string;
  phone: string;
  hours: string;
  isOpen: boolean;
  distance?: string;
}

interface UserProfile {
  name: string;
  dob: string;
  phone: string;
  email: string;
  preferredPharmacy: string;
  language: string;
  biometricEnabled: boolean;
}

interface ContentArticle {
  id: string;
  title: string;
  excerpt: string;
  category: string;
  readTime: string;
  image?: string;
}

// Mock Data
const MOCK_PRESCRIPTIONS: Prescription[] = [
  {
    id: "1",
    name: "Amoxicillin",
    strength: "500mg",
    directions: "Take 1 capsule three times daily with food",
    rxNumber: "RX-2024-001",
    status: "active",
    lastFillDate: "2024-01-15",
    refillable: true,
    refillCount: 2,
  },
  {
    id: "2",
    name: "Lisinopril",
    strength: "10mg",
    directions: "Take 1 tablet daily in the morning",
    rxNumber: "RX-2024-002",
    status: "ready",
    lastFillDate: "2024-01-10",
    refillable: true,
    refillCount: 5,
  },
  {
    id: "3",
    name: "Metformin",
    strength: "850mg",
    directions: "Take with meals to reduce stomach upset",
    rxNumber: "RX-2024-003",
    status: "processing",
    lastFillDate: "2024-01-20",
    refillable: false,
    refillCount: 0,
  },
];

const MOCK_REMINDERS: Reminder[] = [
  { id: "1", medicationName: "Amoxicillin", time: "08:00 AM", taken: false, snoozed: false },
  { id: "2", medicationName: "Amoxicillin", time: "02:00 PM", taken: false, snoozed: false },
  { id: "3", medicationName: "Lisinopril", time: "09:00 AM", taken: true, snoozed: false },
];

const MOCK_APPOINTMENTS: Appointment[] = [
  {
    id: "1",
    service: "Flu Shot",
    date: "2024-02-15",
    time: "10:30 AM",
    status: "upcoming",
    notes: "Bring ID and Alberta Health Card",
  },
];

const MOCK_MESSAGES: Message[] = [
  {
    id: "1",
    sender: "pharmacist",
    text: "Hello! I'm Sarah, your pharmacist. How can I help you today?",
    timestamp: "2024-01-20 09:00",
    category: "General",
  },
];

const MOCK_LOCATIONS: Location[] = [
  {
    id: "1",
    name: "RemedyPills Pharmacy",
    address: "123 4th Ave SW, Calgary, AB T2P 0H3",
    phone: "(403) 123-4567",
    hours: "M-F: 09:00 am - 05:00 pm, Sat: 10 am - 2 pm, Sun: Closed",
    isOpen: true,
    distance: "0.8 km",
  }
];

const MOCK_ARTICLES: ContentArticle[] = [
  {
    id: "1",
    title: "Understanding Your Flu Shot Options",
    excerpt: "Learn about the different flu vaccines available this season and which one is right for you.",
    category: "Vaccinations",
    readTime: "3 min read",
  },
  {
    id: "2",
    title: "Managing Seasonal Allergies",
    excerpt: "Tips from our pharmacists on reducing allergy symptoms during Calgary's allergy season.",
    category: "Wellness",
    readTime: "5 min read",
  },
  {
    id: "3",
    title: "Diabetes Medication Management",
    excerpt: "A guide to organizing and timing your diabetes medications for optimal health.",
    category: "Chronic Care",
    readTime: "4 min read",
  },
];

// Icons Components
const Icons = {
  Home: () => (
    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
    </svg>
  ),
  Pills: () => (
    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
    </svg>
  ),
  Calendar: () => (
    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
    </svg>
  ),
  Heart: () => (
    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
    </svg>
  ),
  Gift: () => (
    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v13m0-13V6a2 2 0 112 2h-2zm0 0V5.5A2.5 2.5 0 109.5 8H12zm-7 4h14M5 12a2 2 0 110-4h14a2 2 0 110 4M5 12v7a2 2 0 002 2h10a2 2 0 002-2v-7" />
    </svg>
  ),
  More: () => (
    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
    </svg>
  ),
  Bell: () => (
    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
    </svg>
  ),
  Chat: () => (
    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
    </svg>
  ),
  MapPin: () => (
    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
    </svg>
  ),
  Phone: () => (
    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
    </svg>
  ),
  Clock: () => (
    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
  ),
  Check: () => (
    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
    </svg>
  ),
  Alert: () => (
    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
    </svg>
  ),
  Camera: () => (
    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
    </svg>
  ),
  QrCode: () => (
    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v1m6 11h2m-2 0h-2m0 0H8m0 0H6m2 0v-2m0 2v2M6 20h2m-2 0H4m2 0v-2m0 2v2m12-6h2m-2 0h-2m0 0H8m0 0H6m2 0v-2m0 2v2M6 8h2m-2 0H4m2 0V6m0 2v2m12-6h2m-2 0h-2m0 0H8m0 0H6m2 0V4m0 2v2" />
    </svg>
  ),
  User: () => (
    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
    </svg>
  ),
  Settings: () => (
    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
    </svg>
  ),
  Shield: () => (
    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
    </svg>
  ),
  BookOpen: () => (
    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
    </svg>
  ),
  Search: () => (
    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
    </svg>
  ),
  ArrowRight: () => (
    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
    </svg>
  ),
  Plus: () => (
    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
    </svg>
  ),
  X: () => (
    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
    </svg>
  ),
  Info: () => (
    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
  ),
};

type TabType = "home" | "prescriptions" | "appointments" | "health" | "more";

export function App() {
  const [activeTab, setActiveTab] = useState<TabType>("home");
  const [userProfile, setUserProfile] = useState<UserProfile>({
    name: "John Doe",
    dob: "1985-03-15",
    phone: "(403) 555-0123",
    email: "john.doe@email.com",
    preferredPharmacy: "RemedyPills Pharmacy",
    language: "English",
    biometricEnabled: false,
  });
  const [prescriptions, setPrescriptions] = useState<Prescription[]>(MOCK_PRESCRIPTIONS);
  const [reminders, setReminders] = useState<Reminder[]>(MOCK_REMINDERS);
  const [appointments, setAppointments] = useState<Appointment[]>(MOCK_APPOINTMENTS);
  const [messages, setMessages] = useState<Message[]>(MOCK_MESSAGES);
  const [showEmergencyModal, setShowEmergencyModal] = useState(false);
  const [showRefillModal, setShowRefillModal] = useState(false);
  const [showChatModal, setShowChatModal] = useState(false);
  const [showBookingModal, setShowBookingModal] = useState(false);
  const [newMessage, setNewMessage] = useState("");
  const [chatCategory, setChatCategory] = useState("General");
  const [notificationPermission, setNotificationPermission] = useState(false);

  // Emergency Disclaimer Handler
  useEffect(() => {
    const timer = setTimeout(() => {
      setShowEmergencyModal(true);
    }, 500);
    return () => clearTimeout(timer);
  }, []);

  // Handlers
  const handleRefillRequest = (prescriptionId: string) => {
    setPrescriptions((prev) =>
      prev.map((p) =>
        p.id === prescriptionId ? { ...p, status: "processing" } : p
      )
    );
    setShowRefillModal(false);
    alert("Refill request submitted successfully!");
  };

  const handleMarkTaken = (reminderId: string) => {
    setReminders((prev) =>
      prev.map((r) => (r.id === reminderId ? { ...r, taken: true } : r))
    );
  };

  const handleSnooze = (reminderId: string) => {
    setReminders((prev) =>
      prev.map((r) => (r.id === reminderId ? { ...r, snoozed: true } : r))
    );
  };

  const handleSendMessage = () => {
    if (!newMessage.trim()) return;
    const message: Message = {
      id: Date.now().toString(),
      sender: "user",
      text: newMessage,
      timestamp: new Date().toISOString(),
      category: chatCategory,
    };
    setMessages((prev) => [...prev, message]);
    setNewMessage("");
    
    // Simulate pharmacist response
    setTimeout(() => {
      const response: Message = {
        id: (Date.now() + 1).toString(),
        sender: "pharmacist",
        text: "Thank you for your message. A pharmacist will respond shortly.",
        timestamp: new Date().toISOString(),
        category: chatCategory,
      };
      setMessages((prev) => [...prev, response]);
    }, 2000);
  };

  const handleBookAppointment = (service: string, date: string, time: string) => {
    const appointment: Appointment = {
      id: Date.now().toString(),
      service,
      date,
      time,
      status: "upcoming",
      notes: "Please bring ID and health card",
    };
    setAppointments((prev) => [...prev, appointment]);
    setShowBookingModal(false);
    alert("Appointment booked successfully!");
  };

  const handleCancelAppointment = (appointmentId: string) => {
    setAppointments((prev) =>
      prev.map((a) => (a.id === appointmentId ? { ...a, status: "cancelled" } : a))
    );
  };

  // Render Helpers
  const getStatusColor = (status: Prescription["status"]) => {
    switch (status) {
      case "active":
        return "bg-emerald-100 text-emerald-700 border-emerald-200";
      case "processing":
        return "bg-amber-100 text-amber-700 border-amber-200";
      case "ready":
        return "bg-sky-100 text-sky-700 border-sky-200";
      case "completed":
        return "bg-slate-100 text-slate-700 border-slate-200";
      default:
        return "bg-slate-100 text-slate-700";
    }
  };

  const getStatusLabel = (status: Prescription["status"]) => {
    switch (status) {
      case "active":
        return "Active";
      case "processing":
        return "Processing";
      case "ready":
        return "Ready for Pickup";
      case "completed":
        return "Completed";
      default:
        return status;
    }
  };

  // Components
  const EmergencyModal = () => (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
            <Icons.Alert />
          </div>
          <h2 className="text-xl font-bold text-slate-900">Medical Emergency</h2>
        </div>
        <p className="text-slate-600 mb-6">
          This app is <span className="font-semibold text-red-600">NOT for emergencies</span>. 
          If you are experiencing a medical emergency, please call 911 immediately.
        </p>
        <div className="space-y-3">
          <a
            href="tel:911"
            className="flex items-center justify-center gap-2 w-full py-3 bg-red-600 text-white rounded-xl font-semibold hover:bg-red-700 transition-colors"
          >
            <Icons.Phone />
            Call 911
          </a>
          <button
            onClick={() => setShowEmergencyModal(false)}
            className="w-full py-3 bg-slate-100 text-slate-700 rounded-xl font-medium hover:bg-slate-200 transition-colors"
          >
            I Understand - Continue to App
          </button>
        </div>
      </div>
    </div>
  );

  const RefillModal = () => (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-end sm:items-center justify-center">
      <div className="bg-white rounded-t-3xl sm:rounded-2xl w-full max-w-lg max-h-[90vh] overflow-auto">
        <div className="p-6 border-b border-slate-100 sticky top-0 bg-white">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-slate-900">Request Refill</h2>
            <button
              onClick={() => setShowRefillModal(false)}
              className="p-2 hover:bg-slate-100 rounded-full transition-colors"
            >
              <Icons.X />
            </button>
          </div>
        </div>
        <div className="p-6 space-y-4">
          {prescriptions
            .filter((p) => p.refillable && p.status === "active")
            .map((prescription) => (
              <div
                key={prescription.id}
                className="border border-slate-200 rounded-xl p-4 hover:border-teal-400 transition-colors cursor-pointer"
                onClick={() => handleRefillRequest(prescription.id)}
              >
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-semibold text-slate-900">{prescription.name}</h3>
                    <p className="text-sm text-slate-500">{prescription.strength}</p>
                    <p className="text-xs text-slate-400 mt-1">Rx: {prescription.rxNumber}</p>
                  </div>
                  <span className="text-sm font-medium text-teal-600">
                    {prescription.refillCount} refills left
                  </span>
                </div>
              </div>
            ))}
          <div className="pt-4 border-t border-slate-100">
            <p className="text-sm text-slate-500 mb-3">Or enter prescription number manually:</p>
            <input
              type="text"
              placeholder="Enter RX number"
              className="w-full px-4 py-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500"
            />
            <button className="w-full mt-3 py-3 bg-teal-600 text-white rounded-xl font-semibold hover:bg-teal-700 transition-colors">
              Submit Refill Request
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  const ChatModal = () => (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-end sm:items-center justify-center">
      <div className="bg-white rounded-t-3xl sm:rounded-2xl w-full max-w-lg h-[80vh] flex flex-col">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-white rounded-t-3xl sm:rounded-t-2xl">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-teal-100 rounded-full flex items-center justify-center">
              <span className="text-teal-700 font-semibold">SP</span>
            </div>
            <div>
              <h2 className="font-semibold text-slate-900">Sarah, Pharmacist</h2>
              <p className="text-xs text-emerald-600">● Online</p>
            </div>
          </div>
          <button
            onClick={() => setShowChatModal(false)}
            className="p-2 hover:bg-slate-100 rounded-full transition-colors"
          >
            <Icons.X />
          </button>
        </div>
        
        <div className="flex-1 overflow-auto p-4 space-y-4 bg-slate-50">
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-3">
            <p className="text-xs text-amber-800 flex items-center gap-2">
              <Icons.Alert />
              Not for emergencies. Call 911 for medical emergencies.
            </p>
          </div>
          
          <div className="flex gap-2 flex-wrap">
            {["Refill Question", "Side Effects", "Insurance", "General"].map((cat) => (
              <button
                key={cat}
                onClick={() => setChatCategory(cat)}
                className={cn(
                  "px-3 py-1.5 rounded-full text-xs font-medium transition-colors",
                  chatCategory === cat
                    ? "bg-teal-600 text-white"
                    : "bg-white border border-slate-200 text-slate-600 hover:border-teal-400"
                )}
              >
                {cat}
              </button>
            ))}
          </div>

          {messages.map((message) => (
            <div
              key={message.id}
              className={cn(
                "flex",
                message.sender === "user" ? "justify-end" : "justify-start"
              )}
            >
              <div
                className={cn(
                  "max-w-[80%] rounded-2xl px-4 py-3",
                  message.sender === "user"
                    ? "bg-teal-600 text-white rounded-br-md"
                    : "bg-white border border-slate-200 text-slate-700 rounded-bl-md"
                )}
              >
                <p className="text-sm">{message.text}</p>
                <p
                  className={cn(
                    "text-xs mt-1",
                    message.sender === "user" ? "text-teal-100" : "text-slate-400"
                  )}
                >
                  {new Date(message.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                </p>
              </div>
            </div>
          ))}
        </div>

        <div className="p-4 border-t border-slate-100 bg-white">
          <div className="flex gap-2">
            <button className="p-2 text-slate-400 hover:text-teal-600 transition-colors">
              <Icons.Camera />
            </button>
            <input
              type="text"
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
              placeholder="Type your message..."
              className="flex-1 px-4 py-2 border border-slate-200 rounded-full focus:outline-none focus:ring-2 focus:ring-teal-500"
            />
            <button
              onClick={handleSendMessage}
              className="p-2 bg-teal-600 text-white rounded-full hover:bg-teal-700 transition-colors"
            >
              <Icons.ArrowRight />
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  const BookingModal = () => {
    const [step, setStep] = useState(1);
    const [selectedService, setSelectedService] = useState("");
    const [selectedDate, setSelectedDate] = useState("");
    const [selectedTime, setSelectedTime] = useState("");

    const services = [
      { name: "Flu Shot", duration: "15 min", prep: "Bring ID and health card" },
      { name: "COVID Booster", duration: "15 min", prep: "Previous vaccination record" },
      { name: "Travel Consultation", duration: "30 min", prep: "Travel itinerary" },
      { name: "Medication Review", duration: "45 min", prep: "All current medications" },
    ];

    const times = ["9:00 AM", "9:30 AM", "10:00 AM", "10:30 AM", "11:00 AM", "2:00 PM", "2:30 PM", "3:00 PM"];

    return (
      <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-end sm:items-center justify-center">
        <div className="bg-white rounded-t-3xl sm:rounded-2xl w-full max-w-lg max-h-[90vh] overflow-auto">
          <div className="p-6 border-b border-slate-100 sticky top-0 bg-white">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-bold text-slate-900">Book Appointment</h2>
              <button
                onClick={() => setShowBookingModal(false)}
                className="p-2 hover:bg-slate-100 rounded-full transition-colors"
              >
                <Icons.X />
              </button>
            </div>
            <div className="flex gap-2 mt-4">
              {[1, 2, 3].map((s) => (
                <div
                  key={s}
                  className={cn(
                    "h-2 flex-1 rounded-full transition-colors",
                    s <= step ? "bg-teal-600" : "bg-slate-200"
                  )}
                />
              ))}
            </div>
          </div>

          <div className="p-6">
            {step === 1 && (
              <div className="space-y-3">
                <h3 className="font-medium text-slate-900 mb-4">Select Service</h3>
                {services.map((service) => (
                  <button
                    key={service.name}
                    onClick={() => {
                      setSelectedService(service.name);
                      setStep(2);
                    }}
                    className={cn(
                      "w-full p-4 border rounded-xl text-left transition-all",
                      selectedService === service.name
                        ? "border-teal-600 bg-teal-50"
                        : "border-slate-200 hover:border-teal-400"
                    )}
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-semibold text-slate-900">{service.name}</h4>
                        <p className="text-sm text-slate-500 mt-1">{service.prep}</p>
                      </div>
                      <span className="text-sm text-teal-600 font-medium">{service.duration}</span>
                    </div>
                  </button>
                ))}
              </div>
            )}

            {step === 2 && (
              <div className="space-y-4">
                <h3 className="font-medium text-slate-900">Select Date & Time</h3>
                <input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  min={new Date().toISOString().split("T")[0]}
                  className="w-full px-4 py-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500"
                />
                <div className="grid grid-cols-2 gap-2">
                  {times.map((time) => (
                    <button
                      key={time}
                      onClick={() => setSelectedTime(time)}
                      className={cn(
                        "py-3 border rounded-xl text-sm font-medium transition-colors",
                        selectedTime === time
                          ? "border-teal-600 bg-teal-50 text-teal-700"
                          : "border-slate-200 hover:border-teal-400"
                      )}
                    >
                      {time}
                    </button>
                  ))}
                </div>
                <button
                  onClick={() => selectedDate && selectedTime && setStep(3)}
                  disabled={!selectedDate || !selectedTime}
                  className="w-full py-3 bg-teal-600 text-white rounded-xl font-semibold hover:bg-teal-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Continue
                </button>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-4">
                <h3 className="font-medium text-slate-900">Confirm Booking</h3>
                <div className="bg-slate-50 rounded-xl p-4 space-y-3">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Service</span>
                    <span className="font-medium text-slate-900">{selectedService}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Date</span>
                    <span className="font-medium text-slate-900">{selectedDate}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Time</span>
                    <span className="font-medium text-slate-900">{selectedTime}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Location</span>
                    <span className="font-medium text-slate-900">{userProfile.preferredPharmacy}</span>
                  </div>
                </div>
                <div className="bg-amber-50 border border-amber-200 rounded-xl p-3">
                  <p className="text-xs text-amber-800">
                    Please arrive 5 minutes early. Bring your ID and Alberta Health Card.
                  </p>
                </div>
                <button
                  onClick={() => handleBookAppointment(selectedService, selectedDate, selectedTime)}
                  className="w-full py-3 bg-teal-600 text-white rounded-xl font-semibold hover:bg-teal-700 transition-colors"
                >
                  Confirm Booking
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  // Tab Content Components
  const HomeTab = () => (
    <div className="space-y-6 pb-24">
      {/* Header */}
      <div className="bg-gradient-to-br from-teal-600 to-teal-700 text-white p-6 -mx-4 -mt-4">
        <div className="flex items-center justify-between mb-6">
          <div className="bg-white p-2 rounded-lg">
            <img 
              src="https://remedypills.ca/wp-content/uploads/2023/10/Remedy-Pills-Pharmacy-Logo-Final-1.png" 
              alt="RemedyPills Logo" 
              className="h-10 object-contain"
            />
          </div>
          <button className="p-2 bg-white/10 rounded-full hover:bg-white/20 transition-colors">
            <Icons.Bell />
          </button>
        </div>

        <div className="mb-4">
          <p className="text-teal-100 text-sm">Welcome back,</p>
          <h1 className="text-2xl font-bold">{userProfile.name}</h1>
        </div>
        
        {/* Quick Stats */}
        <div className="flex gap-4">
          <div className="flex-1 bg-white/10 backdrop-blur rounded-xl p-3">
            <p className="text-teal-100 text-xs">Active Prescriptions</p>
            <p className="text-2xl font-bold">{prescriptions.filter(p => p.status === "active").length}</p>
          </div>
          <div className="flex-1 bg-white/10 backdrop-blur rounded-xl p-3">
            <p className="text-teal-100 text-xs">Next Appointment</p>
            <p className="text-lg font-bold truncate">
              {appointments.find(a => a.status === "upcoming")?.date || "None scheduled"}
            </p>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div>
        <h2 className="text-lg font-semibold text-slate-900 mb-3">Quick Actions</h2>
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={() => setShowRefillModal(true)}
            className="p-4 bg-white border border-slate-200 rounded-xl text-left hover:border-teal-400 hover:shadow-md transition-all"
          >
            <div className="w-10 h-10 bg-teal-100 rounded-lg flex items-center justify-center mb-2">
              <Icons.Pills />
            </div>
            <p className="font-medium text-slate-900">Refill Rx</p>
            <p className="text-xs text-slate-500 mt-1">Request prescription refill</p>
          </button>
          <button
            onClick={() => setShowBookingModal(true)}
            className="p-4 bg-white border border-slate-200 rounded-xl text-left hover:border-teal-400 hover:shadow-md transition-all"
          >
            <div className="w-10 h-10 bg-violet-100 rounded-lg flex items-center justify-center mb-2">
              <Icons.Calendar />
            </div>
            <p className="font-medium text-slate-900">Book Appt</p>
            <p className="text-xs text-slate-500 mt-1">Schedule a service</p>
          </button>
          <button
            onClick={() => setShowChatModal(true)}
            className="p-4 bg-white border border-slate-200 rounded-xl text-left hover:border-teal-400 hover:shadow-md transition-all"
          >
            <div className="w-10 h-10 bg-emerald-100 rounded-lg flex items-center justify-center mb-2">
              <Icons.Chat />
            </div>
            <p className="font-medium text-slate-900">Chat Rx</p>
            <p className="text-xs text-slate-500 mt-1">Message pharmacist</p>
          </button>
          <button
            onClick={() => setActiveTab("more")}
            className="p-4 bg-white border border-slate-200 rounded-xl text-left hover:border-teal-400 hover:shadow-md transition-all"
          >
            <div className="w-10 h-10 bg-amber-100 rounded-lg flex items-center justify-center mb-2">
              <Icons.MapPin />
            </div>
            <p className="font-medium text-slate-900">Find Store</p>
            <p className="text-xs text-slate-500 mt-1">Locate nearest pharmacy</p>
          </button>
        </div>
      </div>

      {/* Today's Reminders */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-semibold text-slate-900">Today's Reminders</h2>
          <button 
            onClick={() => setActiveTab("prescriptions")}
            className="text-sm text-teal-600 font-medium hover:text-teal-700"
          >
            View All
          </button>
        </div>
        <div className="space-y-3">
          {reminders
            .filter((r) => !r.taken)
            .slice(0, 2)
            .map((reminder) => (
              <div
                key={reminder.id}
                className="bg-white border border-slate-200 rounded-xl p-4 flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <div className={cn(
                    "w-12 h-12 rounded-full flex items-center justify-center",
                    reminder.snoozed ? "bg-amber-100 text-amber-600" : "bg-teal-100 text-teal-600"
                  )}>
                    <Icons.Clock />
                  </div>
                  <div>
                    <p className="font-medium text-slate-900">{reminder.medicationName}</p>
                    <p className="text-sm text-slate-500">{reminder.time}</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  {!reminder.snoozed && (
                    <button
                      onClick={() => handleSnooze(reminder.id)}
                      className="px-3 py-1.5 text-sm font-medium text-amber-600 bg-amber-50 rounded-lg hover:bg-amber-100 transition-colors"
                    >
                      Snooze
                    </button>
                  )}
                  <button
                    onClick={() => handleMarkTaken(reminder.id)}
                    className="px-3 py-1.5 text-sm font-medium text-white bg-teal-600 rounded-lg hover:bg-teal-700 transition-colors"
                  >
                    Taken
                  </button>
                </div>
              </div>
            ))}
        </div>
      </div>

      {/* Store Status */}
      <div className="bg-gradient-to-r from-teal-600 to-teal-700 rounded-xl p-4 text-white">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-teal-100 text-sm">{userProfile.preferredPharmacy}</p>
            <p className="font-semibold flex items-center gap-2 mt-1">
              <span className="w-2 h-2 bg-emerald-400 rounded-full"></span>
              M-F: 9am-5pm | Sat: 10am-2pm
            </p>
          </div>
          <button className="p-2 bg-white/10 rounded-lg hover:bg-white/20 transition-colors">
            <Icons.Phone />
          </button>
        </div>
      </div>

      {/* Info Card */}
      <div className="bg-emerald-50 border border-emerald-100 rounded-xl p-4">
        <div className="flex items-start gap-3 text-emerald-800">
          <div className="mt-1"><Icons.Info /></div>
          <div>
            <h3 className="font-semibold">Holiday Hours</h3>
            <p className="text-sm">We are closed on all major holidays. Please plan your refills accordingly.</p>
          </div>
        </div>
      </div>
    </div>
  );

  const PrescriptionsTab = () => (
    <div className="space-y-6 pb-24">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-slate-900">Prescriptions</h1>
        <button
          onClick={() => setShowRefillModal(true)}
          className="px-4 py-2 bg-teal-600 text-white rounded-lg font-medium hover:bg-teal-700 transition-colors flex items-center gap-2"
        >
          <Icons.Plus />
          Refill
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-2">
        {["All", "Active", "Ready", "Processing"].map((filter) => (
          <button
            key={filter}
            className="px-4 py-2 bg-white border border-slate-200 rounded-full text-sm font-medium whitespace-nowrap hover:border-teal-400 transition-colors"
          >
            {filter}
          </button>
        ))}
      </div>

      {/* Prescriptions List */}
      <div className="space-y-4">
        {prescriptions.map((prescription) => (
          <div
            key={prescription.id}
            className="bg-white border border-slate-200 rounded-xl p-4 hover:shadow-md transition-shadow"
          >
            <div className="flex items-start justify-between mb-3">
              <div>
                <h3 className="font-semibold text-slate-900">{prescription.name}</h3>
                <p className="text-sm text-slate-500">{prescription.strength}</p>
              </div>
              <span
                className={cn(
                  "px-3 py-1 rounded-full text-xs font-medium border",
                  getStatusColor(prescription.status)
                )}
              >
                {getStatusLabel(prescription.status)}
              </span>
            </div>
            
            <p className="text-sm text-slate-600 mb-3">{prescription.directions}</p>
            
            <div className="flex items-center justify-between text-xs text-slate-400 mb-3">
              <span>Rx: {prescription.rxNumber}</span>
              <span>Last filled: {prescription.lastFillDate}</span>
            </div>

            {prescription.refillable && prescription.status === "active" && (
              <button
                onClick={() => handleRefillRequest(prescription.id)}
                className="w-full py-2.5 bg-teal-50 text-teal-700 rounded-lg font-medium hover:bg-teal-100 transition-colors"
              >
                Request Refill ({prescription.refillCount} left)
              </button>
            )}

            {prescription.status === "ready" && (
              <button className="w-full py-2.5 bg-emerald-50 text-emerald-700 rounded-lg font-medium hover:bg-emerald-100 transition-colors">
                Ready for Pickup - View Details
              </button>
            )}
          </div>
        ))}
      </div>

      {/* Reminders Section */}
      <div>
        <h2 className="text-lg font-semibold text-slate-900 mb-3">Dosage Reminders</h2>
        <div className="space-y-3">
          {reminders.map((reminder) => (
            <div
              key={reminder.id}
              className={cn(
                "bg-white border rounded-xl p-4 flex items-center justify-between",
                reminder.taken ? "border-slate-200 opacity-60" : "border-slate-200"
              )}
            >
              <div className="flex items-center gap-3">
                <div
                  className={cn(
                    "w-10 h-10 rounded-full flex items-center justify-center",
                    reminder.taken ? "bg-emerald-100 text-emerald-600" : "bg-teal-100 text-teal-600"
                  )}
                >
                  {reminder.taken ? <Icons.Check /> : <Icons.Clock />}
                </div>
                <div>
                  <p className={cn("font-medium", reminder.taken ? "text-slate-500 line-through" : "text-slate-900")}>
                    {reminder.medicationName}
                  </p>
                  <p className="text-sm text-slate-500">{reminder.time}</p>
                </div>
              </div>
              {!reminder.taken && (
                <div className="flex gap-2">
                  <button
                    onClick={() => handleSnooze(reminder.id)}
                    className="px-3 py-1.5 text-xs font-medium text-amber-600 bg-amber-50 rounded-lg"
                  >
                    Snooze
                  </button>
                  <button
                    onClick={() => handleMarkTaken(reminder.id)}
                    className="px-3 py-1.5 text-xs font-medium text-white bg-teal-600 rounded-lg"
                  >
                    Taken
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const AppointmentsTab = () => (
    <div className="space-y-6 pb-24">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-slate-900">Appointments</h1>
        <button
          onClick={() => setShowBookingModal(true)}
          className="px-4 py-2 bg-teal-600 text-white rounded-lg font-medium hover:bg-teal-700 transition-colors flex items-center gap-2"
        >
          <Icons.Plus />
          Book New
        </button>
      </div>

      {/* Upcoming Appointments */}
      <div>
        <h2 className="text-lg font-semibold text-slate-900 mb-3">Upcoming</h2>
        {appointments.filter((a) => a.status === "upcoming").length === 0 ? (
          <div className="text-center py-8 bg-slate-50 rounded-xl">
            <div className="w-16 h-16 bg-slate-200 rounded-full flex items-center justify-center mx-auto mb-3">
              <Icons.Calendar />
            </div>
            <p className="text-slate-500">No upcoming appointments</p>
            <button
              onClick={() => setShowBookingModal(true)}
              className="mt-3 text-teal-600 font-medium hover:text-teal-700"
            >
              Book your first appointment
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {appointments
              .filter((a) => a.status === "upcoming")
              .map((appointment) => (
                <div
                  key={appointment.id}
                  className="bg-white border border-slate-200 rounded-xl p-4 hover:shadow-md transition-shadow"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-violet-100 rounded-xl flex items-center justify-center text-violet-600">
                        <Icons.Calendar />
                      </div>
                      <div>
                        <h3 className="font-semibold text-slate-900">{appointment.service}</h3>
                        <p className="text-sm text-slate-500">
                          {appointment.date} at {appointment.time}
                        </p>
                      </div>
                    </div>
                    <span className="px-3 py-1 bg-emerald-100 text-emerald-700 rounded-full text-xs font-medium">
                      Confirmed
                    </span>
                  </div>
                  
                  {appointment.notes && (
                    <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 mb-3">
                      <p className="text-sm text-amber-800 flex items-center gap-2">
                        <Icons.Info />
                        {appointment.notes}
                      </p>
                    </div>
                  )}

                  <div className="flex gap-2">
                    <button className="flex-1 py-2 border border-slate-200 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors">
                      Reschedule
                    </button>
                    <button
                      onClick={() => handleCancelAppointment(appointment.id)}
                      className="flex-1 py-2 border border-red-200 rounded-lg text-sm font-medium text-red-600 hover:bg-red-50 transition-colors"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              ))}
          </div>
        )}
      </div>

      {/* Services */}
      <div>
        <h2 className="text-lg font-semibold text-slate-900 mb-3">Available Services</h2>
        <div className="grid grid-cols-2 gap-3">
          {[
            { name: "Flu Shot", icon: "💉" },
            { name: "COVID Vaccine", icon: "🦠" },
            { name: "Travel Consult", icon: "✈️" },
            { name: "Med Review", icon: "💊" },
            { name: "Smoking Cessation", icon: "🚭" },
            { name: "Health Check", icon: "❤️" },
          ].map((service) => (
            <button
              key={service.name}
              onClick={() => setShowBookingModal(true)}
              className="p-4 bg-white border border-slate-200 rounded-xl text-center hover:border-teal-400 transition-colors"
            >
              <span className="text-2xl mb-2 block">{service.icon}</span>
              <p className="text-sm font-medium text-slate-900">{service.name}</p>
            </button>
          ))}
        </div>
      </div>
    </div>
  );

  const HealthTab = () => (
    <div className="space-y-6 pb-24">
      <h1 className="text-2xl font-bold text-slate-900">Health Hub</h1>

      {/* Search */}
      <div className="relative">
        <input
          type="text"
          placeholder="Search health topics..."
          className="w-full px-4 py-3 pl-12 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500"
        />
        <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">
          <Icons.Search />
        </div>
      </div>

      {/* Categories */}
      <div className="flex gap-2 overflow-x-auto pb-2">
        {["All", "Vaccinations", "Wellness", "Chronic Care", "Mental Health", "Nutrition"].map((cat) => (
          <button
            key={cat}
            className="px-4 py-2 bg-white border border-slate-200 rounded-full text-sm font-medium whitespace-nowrap hover:border-teal-400 transition-colors"
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Featured Article */}
      <div className="bg-gradient-to-br from-teal-600 to-teal-700 rounded-xl overflow-hidden text-white">
        <div className="p-6">
          <span className="px-3 py-1 bg-white/20 rounded-full text-xs font-medium">Featured</span>
          <h2 className="text-xl font-bold mt-3">Understanding Your Flu Shot Options</h2>
          <p className="text-teal-100 mt-2 text-sm">
            Learn about the different flu vaccines available this season and which one is right for you and your family.
          </p>
          <button className="mt-4 px-4 py-2 bg-white text-teal-700 rounded-lg font-medium text-sm hover:bg-teal-50 transition-colors">
            Read Article
          </button>
        </div>
      </div>

      {/* Articles List */}
      <div>
        <h2 className="text-lg font-semibold text-slate-900 mb-3">Latest Articles</h2>
        <div className="space-y-4">
          {MOCK_ARTICLES.map((article) => (
            <div
              key={article.id}
              className="bg-white border border-slate-200 rounded-xl p-4 hover:shadow-md transition-shadow cursor-pointer"
            >
              <div className="flex gap-4">
                <div className="w-20 h-20 bg-slate-100 rounded-lg flex-shrink-0 flex items-center justify-center">
                  <Icons.BookOpen />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="px-2 py-0.5 bg-teal-100 text-teal-700 rounded text-xs font-medium">
                      {article.category}
                    </span>
                    <span className="text-xs text-slate-400">{article.readTime}</span>
                  </div>
                  <h3 className="font-semibold text-slate-900 line-clamp-2">{article.title}</h3>
                  <p className="text-sm text-slate-500 mt-1 line-clamp-2">{article.excerpt}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Personalized Tips */}
      <div className="bg-violet-50 border border-violet-200 rounded-xl p-4">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 bg-violet-100 rounded-full flex items-center justify-center flex-shrink-0">
            <Icons.Heart />
          </div>
          <div>
            <h3 className="font-semibold text-violet-900">Personalized for You</h3>
            <p className="text-sm text-violet-700 mt-1">
              Based on your medications, we've curated health tips to help you manage your wellness better.
            </p>
            <button className="mt-3 text-sm font-medium text-violet-700 hover:text-violet-800">
              View Recommendations →
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  // Rewards system removed as per request

  const MoreTab = () => (
    <div className="space-y-6 pb-24">
      <h1 className="text-2xl font-bold text-slate-900">More</h1>

      {/* Profile Summary */}
      <div className="bg-white border border-slate-200 rounded-xl p-4">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 bg-teal-100 rounded-full flex items-center justify-center">
            <span className="text-2xl font-bold text-teal-700">
              {userProfile.name.charAt(0)}
            </span>
          </div>
          <div className="flex-1">
            <h2 className="font-semibold text-slate-900">{userProfile.name}</h2>
            <p className="text-sm text-slate-500">{userProfile.email}</p>
            <p className="text-sm text-slate-500">{userProfile.phone}</p>
          </div>
          <button className="p-2 hover:bg-slate-100 rounded-full transition-colors">
            <Icons.Settings />
          </button>
        </div>
      </div>

      {/* Menu Items */}
      <div className="space-y-1">
        {[
          { icon: <Icons.User />, label: "Edit Profile", action: () => {} },
          { icon: <Icons.MapPin />, label: "Store Locator", action: () => {} },
          { icon: <Icons.Chat />, label: "Message History", action: () => setShowChatModal(true) },
          { icon: <Icons.Shield />, label: "Privacy & Security", action: () => {} },
          { icon: <Icons.Bell />, label: "Notifications", action: () => setNotificationPermission(!notificationPermission) },
          { icon: <Icons.BookOpen />, label: "Terms of Use", action: () => {} },
          { icon: <Icons.Info />, label: "Help & Support", action: () => {} },
        ].map((item, idx) => (
          <button
            key={idx}
            onClick={item.action}
            className="w-full flex items-center gap-4 p-4 bg-white border border-slate-200 rounded-xl hover:border-teal-400 transition-colors text-left"
          >
            <span className="text-slate-600">{item.icon}</span>
            <span className="flex-1 font-medium text-slate-900">{item.label}</span>
            <Icons.ArrowRight />
          </button>
        ))}
      </div>

      {/* Locations */}
      <div>
        <h2 className="text-lg font-semibold text-slate-900 mb-3">Our Locations</h2>
        <div className="space-y-4">
          {MOCK_LOCATIONS.map((location) => (
            <div
              key={location.id}
              className="bg-white border border-slate-200 rounded-xl p-4"
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="font-semibold text-slate-900">{location.name}</h3>
                  <p className="text-sm text-slate-500 mt-1">{location.address}</p>
                </div>
                {location.distance && (
                  <span className="px-2 py-1 bg-teal-100 text-teal-700 rounded-lg text-xs font-medium">
                    {location.distance}
                  </span>
                )}
              </div>
              
              <div className="flex items-center gap-2 text-sm text-slate-600 mb-3">
                <Icons.Clock />
                <span>{location.hours}</span>
                {location.isOpen ? (
                  <span className="px-2 py-0.5 bg-emerald-100 text-emerald-700 rounded text-xs font-medium">
                    Open
                  </span>
                ) : (
                  <span className="px-2 py-0.5 bg-red-100 text-red-700 rounded text-xs font-medium">
                    Closed
                  </span>
                )}
              </div>

              <div className="flex gap-2">
                <a
                  href={`tel:${location.phone}`}
                  className="flex-1 py-2 border border-slate-200 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors text-center"
                >
                  Call
                </a>
                <button className="flex-1 py-2 border border-slate-200 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors">
                  Directions
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Language Selector */}
      <div className="bg-white border border-slate-200 rounded-xl p-4">
        <h3 className="font-medium text-slate-900 mb-3">Language / زبان</h3>
        <select
          value={userProfile.language}
          onChange={(e) => setUserProfile({ ...userProfile, language: e.target.value })}
          className="w-full px-4 py-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500"
        >
          <option value="English">English</option>
          <option value="Urdu">اردو (Urdu)</option>
          <option value="Punjabi">ਪੰਜਾਬੀ (Punjabi)</option>
          <option value="Tagalog">Tagalog</option>
        </select>
      </div>

      {/* App Info */}
      <div className="text-center text-sm text-slate-400">
        <p>RemedyPills Pharmacy App v1.0.0</p>
        <p className="mt-1">© 2024 RemedyPills. All rights reserved.</p>
      </div>

      {/* Logout */}
      <button className="w-full py-3 border border-red-200 text-red-600 rounded-xl font-medium hover:bg-red-50 transition-colors">
        Sign Out
      </button>
    </div>
  );

  // Main Render
  return (
    <div className="min-h-screen bg-slate-50">
      {/* Mobile Container */}
      <div className="max-w-md mx-auto min-h-screen bg-white shadow-2xl relative">
        {/* Main Content */}
                  <main className="p-4 pt-6">
          {activeTab === "home" && <HomeTab />}
          {activeTab === "prescriptions" && <PrescriptionsTab />}
          {activeTab === "appointments" && <AppointmentsTab />}
          {activeTab === "health" && <HealthTab />}
          {activeTab === "more" && <MoreTab />}
        </main>

        {/* Bottom Navigation */}
        <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 max-w-md mx-auto">
          <div className="flex justify-around py-2">
            {[
              { id: "home", icon: <Icons.Home />, label: "Home" },
              { id: "prescriptions", icon: <Icons.Pills />, label: "Rx" },
              { id: "appointments", icon: <Icons.Calendar />, label: "Appts" },
              { id: "health", icon: <Icons.Heart />, label: "Health" },
              { id: "more", icon: <Icons.More />, label: "More" },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as TabType)}
                className={cn(
                  "flex flex-col items-center gap-1 px-3 py-2 rounded-lg transition-colors",
                  activeTab === tab.id
                    ? "text-teal-600 bg-teal-50"
                    : "text-slate-400 hover:text-slate-600"
                )}
              >
                {tab.icon}
                <span className="text-xs font-medium">{tab.label}</span>
              </button>
            ))}
          </div>
          {/* Safe area for iOS */}
          <div className="h-safe-area-inset-bottom bg-white" />
        </nav>

        {/* Modals */}
        {showEmergencyModal && <EmergencyModal />}
        {showRefillModal && <RefillModal />}
        {showChatModal && <ChatModal />}
        {showBookingModal && <BookingModal />}
      </div>
    </div>
  );
}
